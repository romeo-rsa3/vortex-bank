from django.conf import settings
from django.http import HttpResponse
from django.urls import include, path


def index(request):
    html = (settings.BASE_DIR / "frontend" / "index.html").read_text(encoding="utf-8")
    return HttpResponse(html)


urlpatterns = [path("api/", include("bank.urls")), path("", index)]
