import secrets

from django.conf import settings
from django.db import models


def new_number():
    return "".join(str(secrets.randbelow(10)) for _ in range(10))


class Account(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="account")
    number = models.CharField(max_length=10, unique=True, default=new_number)
    balance = models.BigIntegerField(default=0)  # stored in cents
    failed_logins = models.PositiveSmallIntegerField(default=0)
    locked_until = models.DateTimeField(null=True, blank=True)

    class Meta:
        constraints = [models.CheckConstraint(condition=models.Q(balance__gte=0), name="balance_non_negative")]


class Transaction(models.Model):
    account = models.ForeignKey(Account, on_delete=models.CASCADE, related_name="transactions")
    kind = models.CharField(max_length=14)  # DEPOSIT, WITHDRAWAL, TRANSFER_IN, TRANSFER_OUT
    amount = models.BigIntegerField()
    counterparty = models.CharField(max_length=150, blank=True)
    balance_after = models.BigIntegerField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-id"]


class Beneficiary(models.Model):
    owner = models.ForeignKey(Account, on_delete=models.CASCADE, related_name="beneficiaries")
    username = models.CharField(max_length=150)
    nickname = models.CharField(max_length=40)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["owner", "username"], name="uniq_beneficiary")]
