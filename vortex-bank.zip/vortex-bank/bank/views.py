import re
from datetime import timedelta
from decimal import Decimal, InvalidOperation

from django.contrib.auth import authenticate, get_user_model
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction
from django.db.models import Count, Q, Sum
from django.db.models.functions import TruncMonth
from django.utils import timezone
from rest_framework.authtoken.models import Token
from rest_framework.decorators import api_view, permission_classes, throttle_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.throttling import AnonRateThrottle

from .models import Account, Beneficiary, Transaction

User = get_user_model()
MAX_FAILS, LOCK_MINUTES = 5, 15
MAX_AMOUNT = Decimal("1000000")
IN, OUT = ("DEPOSIT", "TRANSFER_IN"), ("WITHDRAWAL", "TRANSFER_OUT")
EMAIL_RE = re.compile(r"[^@\s]+@[^@\s]+\.[^@\s]+")


class LoginThrottle(AnonRateThrottle):
    scope = "login"


class RegisterThrottle(AnonRateThrottle):
    scope = "register"


def err(msg, code=400):
    return Response({"error": msg}, status=code)


def to_cents(raw):
    try:
        d = Decimal(str(raw))
    except InvalidOperation:
        raise ValueError("Enter a valid amount.")
    if not d.is_finite() or d <= 0:
        raise ValueError("Amount must be greater than zero.")
    if d > MAX_AMOUNT:
        raise ValueError("Amount exceeds the per-transaction limit.")
    if d != d.quantize(Decimal("0.01")):
        raise ValueError("Use at most 2 decimal places.")
    return int(d * 100)


def snapshot(user):
    a = user.account
    return {"username": user.username, "email": user.email, "account_number": a.number,
            "balance": a.balance, "joined": user.date_joined}


def record(acct, kind, amount, who=""):
    Transaction.objects.create(account=acct, kind=kind, amount=amount,
                               counterparty=who, balance_after=acct.balance)


def find_user(name):
    return User.objects.filter(username__iexact=str(name).strip()).first()


# ---------- authentication ----------

@api_view(["POST"])
@permission_classes([AllowAny])
@throttle_classes([RegisterThrottle])
def register(request):
    u = str(request.data.get("username", "")).strip()
    p = str(request.data.get("password", ""))
    e = str(request.data.get("email", "")).strip()
    if not re.fullmatch(r"\w{3,30}", u, re.ASCII):
        return err("Username must be 3-30 letters, numbers or underscores.")
    if e and not EMAIL_RE.fullmatch(e):
        return err("Enter a valid email address.")
    if find_user(u):
        return err("Username is already taken.", 409)
    try:
        validate_password(p, User(username=u, email=e))
    except ValidationError as ex:
        return err(" ".join(ex.messages))
    try:
        with transaction.atomic():
            user = User.objects.create_user(u, e, p)
            Account.objects.create(user=user)
    except IntegrityError:
        return err("Username is already taken.", 409)
    return Response({"token": Token.objects.create(user=user).key, "user": snapshot(user)}, status=201)


@api_view(["POST"])
@permission_classes([AllowAny])
@throttle_classes([LoginThrottle])
def login(request):
    user = find_user(request.data.get("username", ""))
    password = str(request.data.get("password", ""))
    acct = None
    if user:
        acct, _ = Account.objects.get_or_create(user=user)
        if acct.locked_until and acct.locked_until > timezone.now():
            return err("Account temporarily locked. Try again later.", 423)
    if not user or not authenticate(username=user.username, password=password):
        if acct:
            acct.failed_logins += 1
            if acct.failed_logins >= MAX_FAILS:
                acct.locked_until = timezone.now() + timedelta(minutes=LOCK_MINUTES)
                acct.failed_logins = 0
            acct.save(update_fields=["failed_logins", "locked_until"])
        return err("Invalid username or password.", 401)
    acct.failed_logins, acct.locked_until = 0, None
    acct.save(update_fields=["failed_logins", "locked_until"])
    token, _ = Token.objects.get_or_create(user=user)
    return Response({"token": token.key, "user": snapshot(user)})


@api_view(["POST"])
def logout(request):
    request.auth.delete()
    return Response(status=204)


@api_view(["GET"])
def me(request):
    Account.objects.get_or_create(user=request.user)
    return Response(snapshot(request.user))


@api_view(["PATCH"])
def profile(request):
    e = str(request.data.get("email", "")).strip()
    if e and not EMAIL_RE.fullmatch(e):
        return err("Enter a valid email address.")
    request.user.email = e
    request.user.save(update_fields=["email"])
    return Response(snapshot(request.user))


@api_view(["POST"])
def change_password(request):
    if not request.user.check_password(str(request.data.get("current", ""))):
        return err("Current password is incorrect.", 403)
    new = str(request.data.get("new", ""))
    try:
        validate_password(new, request.user)
    except ValidationError as ex:
        return err(" ".join(ex.messages))
    request.user.set_password(new)
    request.user.save()
    Token.objects.filter(user=request.user).delete()  # sign out every other session
    return Response({"token": Token.objects.create(user=request.user).key})


# ---------- money ----------

@api_view(["POST"])
def deposit(request):
    try:
        amt = to_cents(request.data.get("amount"))
    except ValueError as ex:
        return err(str(ex))
    with transaction.atomic():
        a = Account.objects.select_for_update().get(user=request.user)
        a.balance += amt
        a.save(update_fields=["balance"])
        record(a, "DEPOSIT", amt)
    return Response({"balance": a.balance, "message": "Deposit successful."})


@api_view(["POST"])
def withdraw(request):
    try:
        amt = to_cents(request.data.get("amount"))
    except ValueError as ex:
        return err(str(ex))
    with transaction.atomic():
        a = Account.objects.select_for_update().get(user=request.user)
        if a.balance < amt:
            return err("Insufficient funds.")
        a.balance -= amt
        a.save(update_fields=["balance"])
        record(a, "WITHDRAWAL", amt)
    return Response({"balance": a.balance, "message": "Withdrawal successful."})


@api_view(["POST"])
def transfer(request):
    try:
        amt = to_cents(request.data.get("amount"))
    except ValueError as ex:
        return err(str(ex))
    target = find_user(request.data.get("to", ""))
    if not target:
        return err("Recipient not found.", 404)
    if target.pk == request.user.pk:
        return err("You cannot transfer money to yourself.")
    Account.objects.get_or_create(user=target)
    with transaction.atomic():
        locked = {a.user_id: a for a in
                  Account.objects.select_for_update().filter(user__in=[request.user, target]).order_by("pk")}
        s, r = locked[request.user.pk], locked[target.pk]
        if s.balance < amt:
            return err("Insufficient funds.")
        s.balance -= amt
        r.balance += amt
        s.save(update_fields=["balance"])
        r.save(update_fields=["balance"])
        record(s, "TRANSFER_OUT", amt, target.username)
        record(r, "TRANSFER_IN", amt, request.user.username)
    return Response({"balance": s.balance, "message": f"Sent to {target.username}."})


# ---------- history, analytics, beneficiaries ----------

@api_view(["GET"])
def transactions(request):
    try:
        limit = max(1, min(int(request.query_params.get("limit", 50)), 200))
    except ValueError:
        limit = 50
    qs = request.user.account.transactions.all()[:limit]
    return Response(list(qs.values("id", "kind", "amount", "counterparty", "balance_after", "created_at")))


@api_view(["GET"])
def analytics(request):
    qs = request.user.account.transactions
    inn, out = Q(kind__in=IN), Q(kind__in=OUT)
    totals = qs.aggregate(money_in=Sum("amount", filter=inn), money_out=Sum("amount", filter=out), count=Count("id"))
    months = (qs.annotate(m=TruncMonth("created_at")).values("m").order_by("-m")
              .annotate(money_in=Sum("amount", filter=inn), money_out=Sum("amount", filter=out)))[:6]
    kinds = qs.order_by().values("kind").annotate(n=Count("id"), total=Sum("amount")).order_by("kind")
    trend = list(qs.order_by("-id").values_list("balance_after", flat=True)[:30])[::-1]
    return Response({"money_in": totals["money_in"] or 0, "money_out": totals["money_out"] or 0,
                     "count": totals["count"], "months": [{"month": m["m"], "money_in": m["money_in"],
                     "money_out": m["money_out"]} for m in months], "kinds": list(kinds), "trend": trend})


@api_view(["GET", "POST"])
def beneficiaries(request):
    a = request.user.account
    if request.method == "POST":
        t = find_user(request.data.get("username", ""))
        if not t:
            return err("That user does not exist.", 404)
        if t.pk == request.user.pk:
            return err("You cannot add yourself.")
        nick = str(request.data.get("nickname", "")).strip()[:40] or t.username
        _, created = Beneficiary.objects.get_or_create(owner=a, username=t.username, defaults={"nickname": nick})
        if not created:
            return err("Beneficiary already saved.", 409)
    return Response(list(a.beneficiaries.order_by("nickname").values("id", "nickname", "username")))


@api_view(["DELETE"])
def beneficiary(request, pk):
    deleted, _ = request.user.account.beneficiaries.filter(pk=pk).delete()
    return Response(status=204 if deleted else 404)
