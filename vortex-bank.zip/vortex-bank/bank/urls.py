from django.urls import path

from . import views as v

urlpatterns = [
    path("register", v.register),
    path("login", v.login),
    path("logout", v.logout),
    path("me", v.me),
    path("profile", v.profile),
    path("password", v.change_password),
    path("deposit", v.deposit),
    path("withdraw", v.withdraw),
    path("transfer", v.transfer),
    path("transactions", v.transactions),
    path("analytics", v.analytics),
    path("beneficiaries", v.beneficiaries),
    path("beneficiaries/<int:pk>", v.beneficiary),
]
