# Vortex Bank

A full-stack digital banking app: **Django + Django REST Framework** backend with token authentication, and an animated, responsive single-page front end.

## Features
Sign up / sign in, dashboard with animated balance card and trend chart, deposit, withdraw, transfers, beneficiaries, transaction history, analytics (monthly in/out, breakdown), account settings (email, password change).

## Run it
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python manage.py makemigrations bank
python manage.py migrate
python manage.py runserver
```
Open http://127.0.0.1:8000

## API (all under `/api/`, `Authorization: Token <key>` except register/login)
| Method | Endpoint | Purpose |
|---|---|---|
| POST | `register`, `login`, `logout` | Authentication |
| GET | `me` | Account snapshot (balance in cents) |
| PATCH | `profile` | Update email |
| POST | `password` | Change password (rotates token) |
| POST | `deposit`, `withdraw`, `transfer` | Money movement |
| GET | `transactions?limit=50` | History |
| GET | `analytics` | Totals, monthly summary, breakdown, trend |
| GET/POST, DELETE | `beneficiaries`, `beneficiaries/<id>` | Saved recipients |

## Security
- Passwords hashed by Django (PBKDF2) and checked with Django's password validators
- Token authentication; all endpoints private by default
- Rate limiting on login (10/min) and register (5/min); 5 failed logins lock an account for 15 minutes
- Money stored as integer cents; transfers are atomic, row-locked (`select_for_update`) with a non-negative balance constraint
- Server-side validation of every amount; front end escapes all rendered data (XSS)
- Production: set `DJANGO_DEBUG=0`, `DJANGO_SECRET_KEY`, `DJANGO_ALLOWED_HOSTS` (enables HTTPS redirect and HSTS)

## Roadmap
PostgreSQL + Docker, tests + GitHub Actions, React/TypeScript front end, then the data, streaming and security-monitoring layers (Vortex Insights, Flow, Shield).
